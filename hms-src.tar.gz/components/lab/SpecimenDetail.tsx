import { FlaskConical, History, RotateCcw, Printer, Send } from "lucide-react";
import Card from "../Card";
import { selectedSpecimen, analyteRows, validationSignoff, type ClinicalFlagTone } from "@/lib/lab-data";

const flagStyle: Record<ClinicalFlagTone, string> = {
  normal: "bg-status-green-bg text-status-green",
  high: "bg-status-amber-bg text-status-amber",
  low: "bg-status-blue-bg text-status-blue",
  critical: "bg-status-red-bg text-status-red",
};

export default function SpecimenDetail() {
  const initials = selectedSpecimen.patient
    .split(" ")
    .map((n) => n[0])
    .slice(0, 2)
    .join("");

  return (
    <div className="min-w-0 space-y-3">
      <div className="rounded-xl border border-surface-border bg-white p-3 shadow-card">
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div className="flex items-start gap-2.5">
            <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-slate-800 text-xs font-bold text-white">
              {initials}
            </span>
            <div>
              <div className="flex items-center gap-2">
                <p className="text-sm font-bold text-slate-900">{selectedSpecimen.patient}</p>
                <span className="text-[11px] text-slate-400">
                  {selectedSpecimen.age} · {selectedSpecimen.sex}
                </span>
              </div>
              <p className="mt-0.5 text-[10px] text-slate-500">
                MRN: {selectedSpecimen.mrn} · Ward: {selectedSpecimen.ward} · Bed {selectedSpecimen.bed} · Consultant:{" "}
                {selectedSpecimen.consultant}
              </p>
              <p className="text-[10px] text-slate-400">
                Collection: {selectedSpecimen.collection} · Analyzer: {selectedSpecimen.analyzer}
              </p>
            </div>
          </div>
          <span className="rounded-md bg-slate-100 px-2 py-1 text-right text-[10px] font-bold text-slate-600">
            {selectedSpecimen.specId}
          </span>
        </div>
      </div>

      <Card
        icon={FlaskConical}
        iconClassName="bg-teal-50 text-brand-teal"
        title="Analyte Result Matrix"
        headerClassName="px-4 py-2.5"
        bodyClassName="p-3"
        action={
          <div className="flex items-center gap-2 text-[10px] font-semibold">
            <span className="rounded-full bg-status-blue-bg px-2 py-0.5 text-status-blue">Instrument Interfaced</span>
            <button className="flex items-center gap-1 text-brand-teal hover:underline">
              <History className="h-3 w-3" />
              Show Historical Trend (48h)
            </button>
          </div>
        }
      >
        <div className="divide-y divide-surface-border">
          {analyteRows.map((row) => (
            <div key={row.id} className="flex flex-wrap items-center gap-x-4 gap-y-1.5 py-2.5 text-[11px]">
              <span className="flex-1 font-semibold text-slate-700">{row.name}</span>
              <span className="w-36 shrink-0 font-mono font-bold text-slate-800">
                {row.value} <span className="font-sans font-normal text-slate-400">{row.unit}</span>
              </span>
              <span className="w-28 shrink-0 text-slate-400">{row.range}</span>
              <span className="w-32 shrink-0 text-right">
                <span className={`rounded px-1.5 py-0.5 text-[10px] font-bold ${flagStyle[row.flagTone]}`}>
                  {row.flag}
                </span>
              </span>
            </div>
          ))}
        </div>

        <div className="mt-2 rounded-lg border border-surface-border bg-slate-50 p-2">
          <div className="flex items-center justify-between text-[10px] font-semibold text-slate-600">
            <span>Pathologist & Medical Scientist Validation Sign-off</span>
            <span className="text-slate-400">Audit Timestamp: {validationSignoff.timestamp}</span>
          </div>
          <p className="mt-0.5 text-[10px] leading-snug text-slate-500">{validationSignoff.note}</p>
        </div>

        <div className="mt-2 flex flex-wrap items-center justify-end gap-2">
          <button className="flex items-center gap-1.5 rounded-lg border border-surface-border px-3 py-1.5 text-[11px] font-semibold text-slate-500 hover:bg-slate-50">
            <RotateCcw className="h-3.5 w-3.5" />
            Order Re-test / Dilution
          </button>
          <button className="flex items-center gap-1.5 rounded-lg border border-surface-border px-3 py-1.5 text-[11px] font-semibold text-slate-500 hover:bg-slate-50">
            <Printer className="h-3.5 w-3.5" />
            Print NRA Accredited Report
          </button>
          <button className="flex items-center gap-1.5 rounded-lg bg-brand-teal px-4 py-1.5 text-[11px] font-semibold text-white hover:bg-teal-700">
            <Send className="h-3.5 w-3.5" />
            Validate & Transmit to Ward A Workspace
          </button>
        </div>
      </Card>
    </div>
  );
}
