import { ScanBarcode, Search } from "lucide-react";
import Card from "../Card";
import { queueTabs, specimenItems } from "@/lib/lab-data";

const statusStyle: Record<string, string> = {
  blue: "bg-status-blue-bg text-status-blue",
  red: "bg-status-red-bg text-status-red",
  amber: "bg-status-amber-bg text-status-amber",
  slate: "bg-slate-100 text-slate-500",
};

export default function AccessioningQueue() {
  return (
    <Card
      icon={ScanBarcode}
      iconClassName="bg-teal-50 text-brand-teal"
      title="Accessioning Queue"
      headerClassName="px-4 py-3"
      bodyClassName="p-3"
      action={<span className="text-sm font-bold text-slate-800">76 Total</span>}
    >
      <div className="flex items-center gap-1.5">
        {queueTabs.map((t) => (
          <button
            key={t.id}
            className={`flex items-center gap-1 rounded-md px-2.5 py-1 text-[11px] font-semibold ${
              t.active ? "bg-brand-teal text-white" : "bg-slate-100 text-slate-500 hover:bg-slate-200"
            }`}
          >
            {t.id === "stat" && <span className="h-1.5 w-1.5 rounded-full bg-status-red" />}
            {t.label} ({t.count})
          </button>
        ))}
      </div>

      <div className="mt-2 flex items-center gap-2 rounded-lg border border-surface-border bg-slate-50 px-2.5 py-1 text-[11px] text-slate-400">
        <Search className="h-3.5 w-3.5" />
        SP-2024-8841-CHM
      </div>

      <div className="mt-2 space-y-1.5">
        {specimenItems.map((item) => (
          <div
            key={item.id}
            className={`rounded-lg border px-2.5 py-1.5 ${
              item.selected ? "border-brand-teal bg-teal-50/40 ring-1 ring-brand-teal" : "border-surface-border bg-white"
            }`}
          >
            <div className="flex items-center justify-between gap-2">
              <span className="flex items-center gap-1 font-mono text-[10px] font-semibold text-slate-400">
                {item.urgent && <span className="text-status-red">!</span>}
                {item.specId}
              </span>
              <span className={`rounded px-1.5 py-0.5 text-[10px] font-bold ${statusStyle[item.statusTone]}`}>
                {item.status}
              </span>
            </div>
            <p className="mt-0.5 text-[12px] font-bold text-slate-800">{item.patient}</p>
            <p className="text-[10px] text-slate-500">{item.detail}</p>
            <p className="mt-0.5 flex items-center gap-1.5 text-[10px] text-slate-500">
              <span className={`h-1.5 w-1.5 rounded-full ${item.containerDot}`} />
              <span className="font-medium text-slate-600">{item.container}</span>
              {item.testOrder}
            </p>
          </div>
        ))}
      </div>
    </Card>
  );
}
