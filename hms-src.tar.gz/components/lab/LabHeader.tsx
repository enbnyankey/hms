import { Microscope, LineChart, ClipboardCheck, PlusCircle } from "lucide-react";
import { labHeader } from "@/lib/lab-data";

export default function LabHeader() {
  return (
    <div className="flex flex-wrap items-start justify-between gap-3">
      <div className="flex items-start gap-3">
        <span className="mt-0.5 flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-teal-50 text-brand-teal">
          <Microscope className="h-5 w-5" />
        </span>
        <div>
          <div className="flex flex-wrap items-center gap-2">
            <h1 className="text-lg font-bold text-slate-900">{labHeader.title}</h1>
            <span className="rounded bg-slate-800 px-2 py-0.5 text-[10px] font-bold tracking-wide text-white">
              {labHeader.block}
            </span>
          </div>
          <p className="text-xs text-slate-400">
            {labHeader.supervisor} · {labHeader.role} · <span className="font-semibold text-status-green">{labHeader.lisStatus}</span>
          </p>
        </div>
      </div>
      <div className="flex items-center gap-2">
        <button className="flex items-center gap-1.5 rounded-lg border border-surface-border bg-white px-3 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-50">
          <LineChart className="h-3.5 w-3.5" />
          QC Log (Levey-Jennings)
        </button>
        <button className="flex items-center gap-1.5 rounded-lg border border-surface-border bg-white px-3 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-50">
          <ClipboardCheck className="h-3.5 w-3.5" />
          Batch Validation
        </button>
        <button className="flex items-center gap-1.5 rounded-lg bg-brand-teal px-3 py-2 text-xs font-semibold text-white hover:bg-teal-700">
          <PlusCircle className="h-3.5 w-3.5" />
          Accession Specimen
        </button>
      </div>
    </div>
  );
}
