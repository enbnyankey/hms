"use client";

import { Search, Bell, ChevronDown, RadioTower, PlusCircle } from "lucide-react";
import { facility, currentUser } from "@/lib/mock-data";

export default function Topbar() {
  return (
    <header className="flex flex-wrap items-center gap-3 border-b border-surface-border bg-white px-4 py-3 lg:px-6">
      <button className="flex items-center gap-2 rounded-md border border-surface-border px-3 py-2 text-left hover:bg-slate-50">
        <div className="text-xs leading-tight">
          <p className="font-semibold text-slate-800">{facility.name}</p>
          <p className="text-slate-400">{facility.location}</p>
        </div>
        <ChevronDown className="h-3.5 w-3.5 text-slate-400" />
      </button>

      {/* <div className="flex items-center gap-1 rounded-md bg-slate-100 p-1 text-xs font-semibold text-slate-500">
        <span className="rounded bg-white px-2.5 py-1 text-slate-800 shadow-sm">HMS</span>
        <span className="px-2.5 py-1">CWMS</span>
      </div> */}

      <div className="hidden md:flex flex-1 items-center gap-2 rounded-md border border-surface-border px-3 py-2 text-sm text-slate-400 max-w-xs">
        <Search className="h-4 w-4" />
        <span>Search</span>
        <kbd className="ml-auto rounded bg-slate-100 px-1.5 py-0.5 text-[10px] text-slate-500">⌘K</kbd>
      </div>

      <div className="hidden md:flex items-center gap-2 rounded-md border border-surface-border px-3 py-2 text-xs text-slate-500">
        <RadioTower className="h-3.5 w-3.5 text-brand-teal" />
        <span>DHIMS-2</span>
        <span className="text-slate-400">Synced</span>
      </div>

      <button className="ml-auto flex items-center gap-1.5 rounded-md bg-brand-teal px-3 py-2 text-xs font-semibold text-white hover:bg-teal-700">
        <PlusCircle className="h-3.5 w-3.5" />
        New Registration / Triage
      </button>

      <button className="relative flex h-9 w-9 items-center justify-center rounded-md border border-surface-border text-slate-500 hover:bg-slate-50">
        <Bell className="h-4 w-4" />
        <span className="absolute -top-0.5 -right-0.5 h-2 w-2 rounded-full bg-status-red" />
      </button>

      <div className="flex items-center gap-2 pl-1">
        <div className="flex h-9 w-9 items-center justify-center rounded-full bg-slate-800 text-xs font-semibold text-white">
          KA
        </div>
        <div className="hidden sm:block text-xs leading-tight">
          <p className="font-semibold text-slate-800">{currentUser.name}</p>
          <p className="text-slate-400">{currentUser.role}</p>
        </div>
      </div>
    </header>
  );
}
