import { ShieldAlert, Phone } from "lucide-react";
import { infectionControl } from "@/lib/ward-data";

export default function InfectionControl() {
  return (
    <div className="rounded-xl border border-surface-border bg-white shadow-card">
      <div className="flex items-center justify-between gap-2 border-b border-surface-border px-5 py-4">
        <div className="flex items-center gap-2">
          <ShieldAlert className="h-4 w-4 text-slate-500" />
          <h2 className="text-sm font-bold text-slate-900">Infection Control Status</h2>
        </div>
        <span className="rounded-full bg-slate-100 px-2.5 py-1 text-[10px] font-bold text-slate-500">
          WHO Standard
        </span>
      </div>

      <div className="space-y-3 p-5">
        <div className="flex items-center justify-between rounded-lg border border-surface-border p-3">
          <div>
            <p className="text-xs font-bold text-slate-800">Negative Pressure Suites</p>
          </div>
          <div className="text-right">
            <p className="text-sm font-extrabold text-status-green">{infectionControl.negativePressure.value}</p>
            <p className="text-[10px] text-slate-400">{infectionControl.negativePressure.note}</p>
          </div>
        </div>

        <div className="flex items-center justify-between rounded-lg border border-surface-border p-3">
          <div>
            <p className="text-xs font-bold text-slate-800">Hand Sanitizer Compliance</p>
            <p className="text-[10px] text-slate-400">{infectionControl.handSanitizer.note}</p>
          </div>
          <p className="text-sm font-extrabold text-status-green">{infectionControl.handSanitizer.value}</p>
        </div>

        <div className="flex items-center justify-between rounded-lg border border-surface-border p-3">
          <div>
            <p className="text-xs font-bold text-slate-800">Sterile Linen Inventory</p>
            <p className="text-[10px] text-slate-400">{infectionControl.sterileLinen.note}</p>
          </div>
          <p className="text-sm font-extrabold text-slate-800">{infectionControl.sterileLinen.value}</p>
        </div>

        <div className="flex items-start gap-2 rounded-lg border border-red-100 bg-status-red-bg p-3">
          <Phone className="mt-0.5 h-3.5 w-3.5 shrink-0 text-status-red" />
          <div>
            <p className="text-xs font-bold text-status-red">Need Isolation Escalation?</p>
            <p className="text-[11px] text-slate-600">{infectionControl.escalationContact}</p>
          </div>
        </div>
      </div>
    </div>
  );
}
