import { ChevronDown } from "lucide-react";
import { wardFilters } from "@/lib/ward-data";

export default function WardFilterBar() {
  return (
    <div className="mt-4 flex flex-wrap items-center gap-3 rounded-xl border border-surface-border bg-white p-3 shadow-card">
      <span className="text-[11px] font-bold uppercase tracking-wide text-slate-400">Filter Ward:</span>
      <div className="flex flex-wrap items-center gap-1.5">
        {wardFilters.map((f) => (
          <button
            key={f.id}
            className={`rounded-md px-2.5 py-1.5 text-[11px] font-semibold transition-colors ${
              f.active ? "bg-brand-cyan text-white" : "bg-slate-100 text-slate-500 hover:bg-slate-200"
            }`}
          >
            {f.label} ({f.count})
          </button>
        ))}
      </div>

      <button className="ml-auto flex items-center gap-1.5 rounded-md border border-surface-border px-2.5 py-1.5 text-[11px] font-medium text-slate-500">
        All Acuity Levels
        <ChevronDown className="h-3 w-3" />
      </button>

      <label className="flex items-center gap-1.5 text-[11px] font-medium text-slate-500">
        <input type="checkbox" className="h-3.5 w-3.5 rounded border-surface-border" />
        Isolation Beds Only
      </label>

      <label className="flex items-center gap-1.5 text-[11px] font-medium text-slate-500">
        <input type="checkbox" defaultChecked className="h-3.5 w-3.5 rounded border-surface-border" />
        Staffing Ratio 1:5 Overall
      </label>
    </div>
  );
}
