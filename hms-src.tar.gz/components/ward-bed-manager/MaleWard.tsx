import { BedSingle, Sparkles, SprayCan } from "lucide-react";
import { maleWard, maleCubicles, type WardBed } from "@/lib/ward-data";

const statusStyle: Record<WardBed["status"], { border: string; bg: string; badge: string }> = {
  occupied: { border: "border-surface-border", bg: "bg-white", badge: "bg-slate-100 text-slate-500" },
  discharge: { border: "border-blue-200", bg: "bg-status-blue-bg", badge: "bg-status-blue text-white" },
  sanitizing: { border: "border-amber-200", bg: "bg-status-amber-bg", badge: "bg-status-amber text-white" },
  ready: { border: "border-green-200", bg: "bg-status-green-bg", badge: "bg-status-green text-white" },
};

function WardBedTile({ bed }: { bed: WardBed }) {
  const style = statusStyle[bed.status];

  return (
    <div className={`rounded-lg border p-3.5 ${style.border} ${style.bg}`}>
      <div className="flex items-center justify-between">
        <span className="text-xs font-extrabold text-slate-800">{bed.id}</span>
        <span className={`rounded-full px-2 py-0.5 text-[10px] font-bold ${style.badge}`}>{bed.statusLabel}</span>
      </div>

      {bed.patient && (
        <>
          <p className="mt-2 text-xs font-bold text-slate-800">
            {bed.patient.name}{" "}
            <span className="font-normal text-slate-400">
              {bed.patient.demo} · {bed.patient.mrn} · {bed.patient.day}
            </span>
          </p>
          {bed.dx && <p className="text-[11px] text-slate-500">{bed.dx}</p>}
          {bed.consultant && <p className="text-[11px] text-slate-400">{bed.consultant}</p>}
          {bed.note && <p className="mt-1 text-[11px] font-medium text-slate-600">{bed.note}</p>}
        </>
      )}

      {bed.housekeeping && (
        <div className="mt-2 text-center">
          <SprayCan className="mx-auto h-5 w-5 text-status-amber" />
          <p className="mt-1 text-xs font-bold text-slate-700">{bed.housekeeping.title}</p>
          {bed.housekeeping.lines.map((l) => (
            <p key={l} className="text-[11px] text-slate-400">{l}</p>
          ))}
          <p className="mt-1 text-[11px] font-semibold text-status-amber">{bed.housekeeping.timer}</p>
        </div>
      )}

      {bed.readyDetail && (
        <div className="mt-2 text-center">
          <Sparkles className="mx-auto h-5 w-5 text-status-green" />
          <p className="mt-1 text-xs font-bold text-slate-700">{bed.readyDetail.title}</p>
          {bed.readyDetail.lines.map((l) => (
            <p key={l} className="text-[11px] text-slate-400">{l}</p>
          ))}
        </div>
      )}

      <div className="mt-2.5 flex items-center justify-between border-t border-black/5 pt-2">
        <span className="text-[11px] text-slate-400">
          {bed.meta ?? bed.housekeeping?.staff ?? bed.readyDetail?.note ?? ""}
        </span>
        {bed.actionLabel && (
          <button className="rounded-md bg-brand-cyan px-2.5 py-1 text-[11px] font-semibold text-white hover:bg-cyan-800">
            {bed.actionLabel}
          </button>
        )}
      </div>
    </div>
  );
}

export default function MaleWard() {
  return (
    <section className="rounded-xl border border-surface-border bg-white shadow-card">
      <div className="flex flex-wrap items-start justify-between gap-3 border-b border-surface-border px-5 py-4">
        <div className="flex items-start gap-3">
          <span className="mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-teal-50 text-brand-teal">
            <BedSingle className="h-4 w-4" />
          </span>
          <div>
            <h2 className="text-sm font-bold text-slate-900">{maleWard.name}</h2>
            <p className="text-[11px] text-slate-400">
              {maleWard.location} · Charge Nurse: {maleWard.chargeNurse}
            </p>
          </div>
        </div>
        <div className="text-right text-[11px] text-slate-400">
          <p className="font-semibold text-slate-600">{maleWard.bedsTotal}</p>
          <p>
            {maleWard.dayShiftStaff} · {maleWard.ratio}
          </p>
          <p className="font-semibold text-slate-600">{maleWard.occupancy}</p>
        </div>
      </div>

      <div className="space-y-5 p-5">
        {maleCubicles.map((cubicle) => (
          <div key={cubicle.id}>
            <div className="mb-2 flex flex-wrap items-baseline justify-between gap-1">
              <p className="text-[11px] font-bold uppercase tracking-wide text-slate-500">{cubicle.title}</p>
              <span className="text-[11px] text-slate-400">{cubicle.subtitle}</span>
            </div>
            <div className="grid gap-3 sm:grid-cols-2">
              {cubicle.beds.map((bed) => (
                <WardBedTile key={bed.id} bed={bed} />
              ))}
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}
