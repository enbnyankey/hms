import { Building2, Activity, ClipboardList, LogOut, BellRing, PlusCircle } from "lucide-react";

export default function WardHeader() {
  return (
    <div className="flex flex-wrap items-start justify-between gap-4">
      <div className="flex items-start gap-3">
        <span className="mt-0.5 flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-slate-100 text-slate-500">
          <Building2 className="h-4 w-4" />
        </span>
        <div>
          <p className="text-[11px] font-semibold uppercase tracking-wide text-slate-400">
            Ward Infrastructure
          </p>
          <h1 className="text-2xl font-extrabold tracking-tight text-slate-900">Ward & Bed Matrix Manager</h1>
          <p className="text-xs text-slate-500">Korle-Bu Inpatient Sector (Blocks A-D)</p>
        </div>
      </div>

      <div className="flex flex-col items-end gap-2">
        <div className="flex items-center gap-1.5 text-[11px] font-semibold text-status-green">
          <Activity className="h-3.5 w-3.5" />
          Real-Time Census
          <span className="font-normal text-slate-400">· Live Bed Flow & Infection Isolation Grid</span>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <button className="flex items-center gap-1.5 rounded-md border border-surface-border bg-white px-3 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-50">
            <ClipboardList className="h-3.5 w-3.5" />
            Ward Census
          </button>
          <button className="flex items-center gap-1.5 rounded-md border border-surface-border bg-white px-3 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-50">
            <LogOut className="h-3.5 w-3.5" />
            Discharge Tracker
          </button>
          <button className="flex items-center gap-1.5 rounded-md border border-surface-border bg-white px-3 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-50">
            <BellRing className="h-3.5 w-3.5" />
            Reallocation Alert
          </button>
          <button className="flex items-center gap-1.5 rounded-md bg-brand-teal px-3 py-2 text-xs font-semibold text-white hover:bg-teal-700">
            <PlusCircle className="h-3.5 w-3.5" />
            New Bed Admission
          </button>
        </div>
      </div>
    </div>
  );
}
