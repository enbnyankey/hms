import { UserPlus2 } from "lucide-react";
import { admissionsQueue, urgentHoldsCount, type QueueUrgency } from "@/lib/ward-data";

const urgencyStyle: Record<QueueUrgency, { border: string; bg: string; text: string; button: string }> = {
  critical: {
    border: "border-red-200",
    bg: "bg-status-red-bg",
    text: "text-status-red",
    button: "bg-status-red hover:bg-red-700",
  },
  warning: {
    border: "border-amber-200",
    bg: "bg-status-amber-bg",
    text: "text-status-amber",
    button: "bg-brand-cyan hover:bg-cyan-800",
  },
  neutral: {
    border: "border-surface-border",
    bg: "bg-slate-50",
    text: "text-slate-500",
    button: "bg-brand-cyan hover:bg-cyan-800",
  },
};

export default function AdmissionsQueue() {
  return (
    <div className="rounded-xl border border-surface-border bg-white shadow-card">
      <div className="flex items-center justify-between gap-2 border-b border-surface-border px-5 py-4">
        <div className="flex items-center gap-2">
          <UserPlus2 className="h-4 w-4 text-slate-500" />
          <h2 className="text-sm font-bold text-slate-900">Admissions Queue</h2>
        </div>
        <span className="rounded-full bg-status-red-bg px-2.5 py-1 text-[10px] font-bold text-status-red">
          {urgentHoldsCount} Urgent Holds
        </span>
      </div>

      <div className="p-5 pt-3">
        <p className="text-[11px] leading-snug text-slate-400">
          Patients triaged in Emergency Department and Recovery waiting for designated ward bed allocation.
        </p>

        <div className="mt-3 space-y-3">
          {admissionsQueue.map((req) => {
            const style = urgencyStyle[req.urgency];
            return (
              <div key={req.id} className={`rounded-lg border p-3.5 ${style.border} ${style.bg}`}>
                <div className="flex items-center justify-between">
                  <span className={`text-[11px] font-bold uppercase tracking-wide ${style.text}`}>{req.source}</span>
                  <span className="text-[10px] font-semibold text-slate-400">{req.wait}</span>
                </div>
                <p className="mt-1.5 text-xs font-bold text-slate-800">
                  {req.patient} <span className="font-normal text-slate-400">{req.demo} · {req.location}</span>
                </p>
                <p className="text-[11px] text-slate-500">Dx: {req.dx}</p>
                <p className="mt-1 text-[11px] text-slate-400">{req.note}</p>
                <div className="mt-2.5 flex items-center justify-between border-t border-black/5 pt-2">
                  <span className="text-[11px] font-semibold text-slate-500">Suggested Bed: {req.suggestedBed}</span>
                  <button className={`rounded-md px-2.5 py-1 text-[11px] font-semibold text-white ${style.button}`}>
                    {req.actionLabel}
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
