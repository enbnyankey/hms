import { HeartHandshake } from "lucide-react";
import { femaleWard, femaleBeds, type SimpleBed } from "@/lib/ward-data";

const dotTone: Record<SimpleBed["status"], string> = {
  occupied: "bg-brand-cyan",
  available: "bg-status-green",
  cleaned: "bg-status-blue",
  hold: "bg-status-amber",
};

const bgTone: Record<SimpleBed["status"], string> = {
  occupied: "border-surface-border bg-white",
  available: "border-green-200 bg-status-green-bg",
  cleaned: "border-blue-200 bg-status-blue-bg",
  hold: "border-amber-200 bg-status-amber-bg",
};

export default function FemaleWard() {
  return (
    <section className="rounded-xl border border-surface-border bg-white shadow-card">
      <div className="flex flex-wrap items-start justify-between gap-2 border-b border-surface-border px-4 py-3">
        <div className="flex items-start gap-3">
          <span className="mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-pink-50 text-pink-500">
            <HeartHandshake className="h-4 w-4" />
          </span>
          <div>
            <h2 className="text-sm font-bold text-slate-900">{femaleWard.name}</h2>
            <p className="text-[11px] text-slate-400">
              {femaleWard.location} · Charge Nurse: {femaleWard.chargeNurse}
            </p>
          </div>
        </div>
        <div className="text-right text-[11px] text-slate-400">
          <p className="font-semibold text-slate-600">{femaleWard.bedsTotal}</p>
          <p>{femaleWard.turnaround}</p>
          <p className="font-semibold text-status-amber">{femaleWard.dischargesPending}</p>
        </div>
      </div>

      <div className="grid grid-cols-4 gap-2 p-4">
        {femaleBeds.map((bed) => (
          <div key={bed.id} className={`rounded-lg border p-2 text-center ${bgTone[bed.status]}`}>
            <p className="text-[11px] font-bold text-slate-700">{bed.id}</p>
            <p className="mt-0.5 truncate text-[10px] text-slate-500">{bed.label}</p>
            <span className={`mx-auto mt-1 block h-1.5 w-1.5 rounded-full ${dotTone[bed.status]}`} />
          </div>
        ))}
      </div>
    </section>
  );
}
