import { Snowflake, Sparkles, Clock } from "lucide-react";
import { icuWard, icuBeds, type IcuBed } from "@/lib/ward-data";

const statusStyle: Record<IcuBed["status"], { border: string; bg: string; badge: string }> = {
  occupied: { border: "border-surface-border", bg: "bg-white", badge: "bg-slate-100 text-slate-500" },
  alert: { border: "border-red-200", bg: "bg-status-red-bg", badge: "bg-status-red text-white" },
  ready: { border: "border-green-200", bg: "bg-status-green-bg", badge: "bg-status-green text-white" },
  reserved: { border: "border-amber-200", bg: "bg-status-amber-bg", badge: "bg-status-amber text-white" },
};

function IcuBedTile({ bed }: { bed: IcuBed }) {
  const style = statusStyle[bed.status];

  return (
    <div className={`rounded-lg border p-3.5 ${style.border} ${style.bg}`}>
      <div className="flex items-center justify-between">
        <span className="text-xs font-extrabold text-slate-800">{bed.id}</span>
        <span className={`rounded-full px-2 py-0.5 text-[10px] font-bold ${style.badge}`}>{bed.statusLabel}</span>
      </div>

      {bed.patient && (
        <>
          <p className="mt-2 text-xs font-bold text-slate-800">
            {bed.patient.name}
            {bed.patient.demo && <span className="ml-1 font-normal text-slate-400">{bed.patient.demo}</span>}
            {bed.patient.mrn && <span className="ml-1 font-normal text-slate-400">· {bed.patient.mrn}</span>}
          </p>
          {bed.dx && <p className="text-[11px] text-slate-500">Dx: {bed.dx}</p>}
          {bed.attending && <p className="text-[11px] text-slate-400">{bed.attending}</p>}
          {bed.extraNote && <p className="text-[11px] text-slate-400">{bed.extraNote}</p>}
        </>
      )}

      {bed.vitals && (
        <div className="mt-2 flex flex-wrap gap-x-3 gap-y-0.5 text-[11px] font-medium text-slate-600">
          {bed.vitals.map((v) => (
            <span key={v.label}>
              {v.label}: <span className="font-bold">{v.value}</span>
            </span>
          ))}
        </div>
      )}

      {bed.readyDetail && (
        <div className="mt-2 text-center">
          <Sparkles className="mx-auto h-5 w-5 text-status-green" />
          <p className="mt-1 text-xs font-bold text-slate-700">{bed.readyDetail.title}</p>
          {bed.readyDetail.lines.map((l) => (
            <p key={l} className="text-[11px] text-slate-400">{l}</p>
          ))}
        </div>
      )}

      <div className="mt-2.5 flex items-center justify-between border-t border-black/5 pt-2">
        <span className="flex items-center gap-1 text-[11px] text-slate-400">
          {bed.meta && (
            <>
              <Clock className="h-3 w-3" />
              {bed.meta}
            </>
          )}
          {bed.readyDetail?.note && !bed.meta && (
            <>
              <Clock className="h-3 w-3" />
              {bed.readyDetail.note}
            </>
          )}
        </span>
        {bed.actionLabel && (
          <button
            className={`rounded-md px-2.5 py-1 text-[11px] font-semibold text-white ${
              bed.actionTone === "danger" ? "bg-status-red hover:bg-red-700" : "bg-brand-cyan hover:bg-cyan-800"
            }`}
          >
            {bed.actionLabel}
          </button>
        )}
      </div>
    </div>
  );
}

export default function IcuWard() {
  return (
    <section className="rounded-xl border border-surface-border bg-white shadow-card">
      <div className="flex flex-wrap items-start justify-between gap-3 border-b border-surface-border px-5 py-4">
        <div className="flex items-start gap-3">
          <span className="mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-blue-50 text-status-blue">
            <Snowflake className="h-4 w-4" />
          </span>
          <div>
            <h2 className="text-sm font-bold text-slate-900">{icuWard.name}</h2>
            <p className="text-[11px] text-slate-400">
              {icuWard.location} · Charge Nurse: {icuWard.chargeNurse}
            </p>
            <p className="text-[11px] font-semibold text-slate-500">{icuWard.occupancy}</p>
          </div>
        </div>
        <div className="flex items-center gap-4 text-right text-[11px] text-slate-400">
          <div>
            <p className="font-semibold text-slate-600">Max Acuity</p>
            <p>Nurse Ratio {icuWard.nurseRatio}</p>
          </div>
          <div>
            <p className="font-semibold text-slate-600">O2 Central</p>
            <p>{icuWard.o2Pressure}</p>
          </div>
        </div>
      </div>

      <div className="grid gap-3 p-5 sm:grid-cols-2">
        {icuBeds.map((bed) => (
          <IcuBedTile key={bed.id} bed={bed} />
        ))}
      </div>
    </section>
  );
}
