import { Siren, Activity } from "lucide-react";
import Card from "./Card";
import { triageFeed, triageLevelMeta, triageSummary } from "@/lib/mock-data";

export default function TriageFeed() {
  return (
    <Card
      icon={Siren}
      iconClassName="bg-status-red-bg text-status-red"
      title="Accra Trauma & Emergency Triage Feed"
      subtitle="Real-time Manchester Triage Categorization · Resuscitation Quad Bay"
      action={
        <div className="flex items-center gap-3 text-[11px] font-semibold">
          <LegendDot color="bg-status-red" label={`Red: ${triageSummary.red}`} />
          <LegendDot color="bg-status-orange" label={`Orange: ${triageSummary.orange}`} />
          <LegendDot color="bg-amber-400" label={`Yellow: ${triageSummary.yellow}`} />
          <LegendDot color="bg-status-green" label={`Green: ${triageSummary.green}`} />
        </div>
      }
      className="h-full flex flex-col"
      bodyClassName="p-5 flex-1"
    >
      <div className="overflow-x-auto">
        <table className="w-full min-w-[640px] text-left text-xs">
          <thead>
            <tr className="text-[11px] uppercase tracking-wide text-slate-400">
              <th className="pb-2 font-semibold">Triage ID & Patient</th>
              <th className="pb-2 font-semibold">Category</th>
              <th className="pb-2 font-semibold">Chief Complaint</th>
              <th className="pb-2 font-semibold">Assigned Bay / MD</th>
              <th className="pb-2 font-semibold">Elapsed</th>
              <th className="pb-2 font-semibold text-right">Action</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-surface-border">
            {triageFeed.map((patient) => {
              const meta = triageLevelMeta[patient.level];
              return (
                <tr key={patient.id} className="align-top">
                  <td className="py-3 pr-3">
                    <p className="font-semibold text-slate-800">{patient.name}</p>
                    <p className="text-[11px] text-slate-400">
                      {patient.mrn} · {patient.age}y / {patient.sex}
                    </p>
                  </td>
                  <td className="py-3 pr-3">
                    <span
                      className={`inline-block rounded px-2 py-0.5 text-[10px] font-bold ${meta.bgClass} ${meta.textClass}`}
                    >
                      {meta.label}
                    </span>
                    <p className="mt-1 text-[11px] text-slate-500">{patient.category}</p>
                  </td>
                  <td className="py-3 pr-3 text-slate-500">{patient.chiefComplaint}</td>
                  <td className="py-3 pr-3">
                    <p className="font-medium text-slate-700">{patient.assignedBay}</p>
                    <p className="text-[11px] text-slate-400">{patient.assignedMd}</p>
                  </td>
                  <td className="py-3 pr-3 font-mono font-semibold text-slate-700">{patient.elapsed}</td>
                  <td className="py-3 text-right">
                    <button className="inline-flex h-7 w-7 items-center justify-center rounded-md text-status-red hover:bg-status-red-bg">
                      <Activity className="h-4 w-4" />
                    </button>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </Card>
  );
}

function LegendDot({ color, label }: { color: string; label: string }) {
  return (
    <span className="flex items-center gap-1 text-slate-500">
      <span className={`h-2 w-2 rounded-full ${color}`} />
      {label}
    </span>
  );
}
