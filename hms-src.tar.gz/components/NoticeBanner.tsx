import { AlertTriangle } from "lucide-react";
import { clinicalNotice, facility } from "@/lib/mock-data";

export default function NoticeBanner() {
  return (
    <div className="flex flex-wrap items-center gap-3 border-b border-red-100 bg-status-red-bg px-4 py-2 text-xs lg:px-6">
      <span className="flex items-center gap-1.5 rounded bg-status-red px-2 py-1 font-bold uppercase tracking-wide text-white">
        <AlertTriangle className="h-3.5 w-3.5" />
        Clinical Notice
      </span>
      <p className="flex-1 min-w-[240px] text-slate-700">{clinicalNotice}</p>
      <span className="text-slate-400">Sync {facility.syncTime}</span>
      <a href="#" className="font-semibold text-brand-cyan hover:underline">
        Review Protocol
      </a>
    </div>
  );
}
