"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { HeartPulse, PhoneCall, Settings } from "lucide-react";
import { navItems, navSectionLabel } from "@/lib/nav";
import { facility } from "@/lib/mock-data";

export default function Sidebar() {
  const pathname = usePathname();

  return (
    <aside className="hidden lg:flex w-64 shrink-0 flex-col bg-sidebar text-slate-200">
      <div className="flex items-center gap-2 px-5 py-5 border-b border-sidebar-border">
        <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-brand-teal/20 text-brand-teal">
          <HeartPulse className="h-5 w-5" strokeWidth={2.25} />
        </div>
        <div className="leading-tight">
          <p className="text-sm font-bold text-white">AuraHealth HMS</p>
          <p className="text-[11px] text-slate-400">Enterprise Clinical Cloud</p>
        </div>
      </div>

      <nav className="flex-1 overflow-y-auto px-3 py-4">
        <p className="px-3 pb-2 text-[11px] font-semibold tracking-wider text-slate-500">
          {navSectionLabel.toUpperCase()}
        </p>
        <ul className="space-y-1">
          {navItems.map((item) => {
            const active = pathname === item.href;
            const Icon = item.icon;
            return (
              <li key={item.href}>
                <Link
                  href={item.href}
                  className={`flex items-center gap-3 rounded-md px-3 py-2 text-sm font-medium transition-colors ${
                    active
                      ? "bg-sidebar-active text-white"
                      : "text-slate-300 hover:bg-sidebar-hover hover:text-white"
                  }`}
                >
                  <Icon className="h-4 w-4 shrink-0" strokeWidth={2} />
                  <span className="truncate">{item.label}</span>
                </Link>
              </li>
            );
          })}
        </ul>
      </nav>

      <div className="border-t border-sidebar-border px-4 py-4 space-y-3">
        <div className="flex items-center gap-2 rounded-md bg-sidebar-hover px-3 py-2">
          <span className="relative flex h-2 w-2">
            <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-400 opacity-75" />
            <span className="relative inline-flex h-2 w-2 rounded-full bg-emerald-400" />
          </span>
          <div className="text-[11px] leading-tight">
            <p className="font-semibold text-white">Day Shift Active</p>
            <p className="text-slate-400">{facility.shiftLabel.replace("Day Shift A ", "")}</p>
          </div>
        </div>
        <div className="flex items-center justify-between px-1 text-[11px] text-slate-400">
          <button className="flex items-center gap-1.5 text-status-red hover:text-red-400">
            <PhoneCall className="h-3.5 w-3.5" />
            Emergency Hotlines
          </button>
          <button className="flex items-center gap-1.5 hover:text-white">
            <Settings className="h-3.5 w-3.5" />
            Settings
          </button>
        </div>
      </div>
    </aside>
  );
}
