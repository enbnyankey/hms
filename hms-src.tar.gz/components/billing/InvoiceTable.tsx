import { invoiceFilters, invoices, invoicesFooter, type InvoiceStatus } from "@/lib/billing-data";

const statusStyle: Record<InvoiceStatus, string> = {
  "Partial Paid": "bg-status-blue-bg text-status-blue",
  Adjudicating: "bg-status-amber-bg text-status-amber",
  Unpaid: "bg-status-red-bg text-status-red",
  "Paid in Full": "bg-status-green-bg text-status-green",
  Cleared: "bg-status-green-bg text-status-green",
};

export default function InvoiceTable() {
  return (
    <div className="rounded-xl border max-h-150 border-surface-border bg-white shadow-card">
      <div className="flex flex-wrap items-start justify-between gap-3 border-b border-surface-border px-5 py-4">
        <div>
          <h2 className="text-sm font-bold text-slate-900">Active Patient Invoices</h2>
          <p className="text-[11px] text-slate-400">
            Clinical service charge ledgers, co-pays, and discharge accounts
          </p>
        </div>
        <div className="flex items-center gap-1 rounded-md bg-slate-100 p-1">
          {invoiceFilters.map((f) => (
            <button
              key={f.id}
              className={`rounded px-2.5 py-1.5 text-[11px] font-semibold ${
                f.active ? "bg-white text-slate-800 shadow-sm" : "text-slate-500"
              }`}
            >
              {f.label} ({f.count})
            </button>
          ))}
        </div>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full min-w-[720px] text-left text-xs">
          <thead>
            <tr className="text-[10px] uppercase tracking-wide text-slate-400">
              <th className="px-5 pb-2 pt-3 font-semibold">Invoice & Patient</th>
              <th className="pb-2 pt-3 font-semibold">Encounter / Scheme</th>
              <th className="pb-2 pt-3 text-right font-semibold">Total (GHS)</th>
              <th className="pb-2 pt-3 text-right font-semibold">Insurance</th>
              <th className="pb-2 pt-3 text-right font-semibold">Balance Due</th>
              <th className="px-5 pb-2 pt-3 text-right font-semibold">Status</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-surface-border">
            {invoices.map((inv) => (
              <tr key={inv.id} className="align-top hover:bg-slate-50">
                <td className="px-5 py-3">
                  <p className="font-mono text-[11px] font-semibold text-brand-cyan">{inv.id}</p>
                  <p className="font-semibold text-slate-800">{inv.patient}</p>
                  <p className="text-[11px] text-slate-400">{inv.mrn}</p>
                </td>
                <td className="py-3 pr-3">
                  <p className="font-medium text-slate-700">{inv.encounter}</p>
                  <p className="text-[11px] text-brand-cyan">{inv.scheme}</p>
                </td>
                <td className="py-3 pr-3 text-right font-mono font-semibold text-slate-700">{inv.total}</td>
                <td className="py-3 pr-3 text-right font-mono text-slate-500">{inv.insurance}</td>
                <td
                  className={`py-3 pr-3 text-right font-mono font-bold ${
                    inv.balance === "0.00" ? "text-slate-400" : "text-status-red"
                  }`}
                >
                  {inv.balance}
                </td>
                <td className="px-5 py-3 text-right">
                  <span className={`inline-block rounded-full px-2.5 py-1 text-[10px] font-bold ${statusStyle[inv.status]}`}>
                    {inv.status}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="flex flex-wrap items-center justify-between gap-2 border-t border-surface-border px-5 py-3 text-[11px] text-slate-400">
        <div className="flex items-center gap-3">
          <span>{invoicesFooter.showing}</span>
          <span className="flex items-center gap-1 font-semibold text-status-green">
            <span className="h-1.5 w-1.5 rounded-full bg-status-green" />
            {invoicesFooter.cashierDesk}
          </span>
        </div>
        <div className="flex items-center gap-1">
          <button className="rounded-md border border-surface-border px-2.5 py-1 font-semibold hover:bg-slate-50">
            Prev
          </button>
          <button className="rounded-md bg-brand-cyan px-2.5 py-1 font-semibold text-white">1</button>
          <button className="rounded-md border border-surface-border px-2.5 py-1 font-semibold hover:bg-slate-50">
            2
          </button>
          <button className="rounded-md border border-surface-border px-2.5 py-1 font-semibold hover:bg-slate-50">
            3
          </button>
          <button className="rounded-md border border-surface-border px-2.5 py-1 font-semibold hover:bg-slate-50">
            Next
          </button>
        </div>
      </div>
    </div>
  );
}
