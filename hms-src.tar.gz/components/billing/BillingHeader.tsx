import { Receipt, CalendarDays, ChevronDown, FilePlus2, Wallet, ShieldCheck, FileSpreadsheet } from "lucide-react";
import { billingHeader } from "@/lib/billing-data";

export default function BillingHeader() {
  return (
    <div className="flex flex-col gap-4">
      <div className="flex flex-wrap items-start justify-between gap-4">
        <div className="flex items-start gap-3">
          <span className="mt-0.5 flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-slate-100 text-slate-500">
            <Receipt className="h-4 w-4" />
          </span>
          <div>
            <div className="flex flex-wrap items-center gap-2">
              <h1 className="text-2xl font-extrabold tracking-tight text-slate-900">{billingHeader.title}</h1>
              <span className="rounded-md bg-status-blue-bg px-2 py-1 text-[11px] font-semibold text-status-blue">
                {billingHeader.wing}
              </span>
            </div>
            <p className="text-xs text-slate-500">{billingHeader.subtitle}</p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button className="flex items-center gap-1.5 rounded-md border border-surface-border bg-white px-3 py-2 text-xs font-medium text-slate-600 hover:bg-slate-50">
            <CalendarDays className="h-3.5 w-3.5 text-slate-400" />
            {billingHeader.date}
            <ChevronDown className="h-3 w-3 text-slate-400" />
          </button>
          <button className="flex items-center gap-1.5 rounded-md border border-surface-border bg-white px-3 py-2 text-xs font-medium text-slate-600 hover:bg-slate-50">
            {billingHeader.department}
            <ChevronDown className="h-3 w-3 text-slate-400" />
          </button>
          <button className="flex items-center gap-1.5 rounded-md border border-surface-border bg-white px-3 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-50">
            <FilePlus2 className="h-3.5 w-3.5" />
            Generate Bill
          </button>
        </div>
      </div>

      <div className="flex flex-wrap items-center gap-2">
        <button className="flex items-center gap-1.5 rounded-md bg-brand-teal px-3 py-2 text-xs font-semibold text-white hover:bg-teal-700">
          <Wallet className="h-3.5 w-3.5" />
          Receive Payment
        </button>
        <button className="flex items-center gap-1.5 rounded-md bg-indigo-600 px-3 py-2 text-xs font-semibold text-white hover:bg-indigo-700">
          <ShieldCheck className="h-3.5 w-3.5" />
          Batch NHIS
        </button>
        <button className="flex items-center gap-1.5 rounded-md border border-surface-border bg-white px-3 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-50">
          <FileSpreadsheet className="h-3.5 w-3.5" />
          Reconciliation
        </button>
      </div>
    </div>
  );
}
