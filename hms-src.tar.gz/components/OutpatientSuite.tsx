import { Stethoscope } from "lucide-react";
import Card from "./Card";
import { outpatientRooms } from "@/lib/mock-data";

export default function OutpatientSuite() {
  const activeCount = outpatientRooms.length;

  return (
    <Card
      icon={Stethoscope}
      iconClassName="bg-teal-50 text-brand-teal"
      title="Specialist Outpatient Consulting Suite"
      subtitle="Real-time room occupancy, waiting patient counts & session flow"
      action={
        <span className="rounded-full bg-slate-100 px-2.5 py-1 text-[11px] font-semibold text-slate-500">
          Rooms Active: {activeCount} / 6
        </span>
      }
    >
      <div className="grid gap-3 sm:grid-cols-2">
        {outpatientRooms.map((room) => (
          <div key={room.id} className="rounded-lg border border-surface-border p-3">
            <div className="flex items-center justify-between">
              <span className="flex items-center gap-1.5 text-xs font-bold text-slate-800">
                <span className="h-1.5 w-1.5 rounded-full bg-status-green" />
                {room.room}
              </span>
              <span className="text-[11px] font-medium text-slate-400">{room.avgWait}</span>
            </div>
            <p className="mt-1.5 text-xs font-semibold text-slate-600">{room.clinician}</p>
            <p className="text-[11px] text-slate-400">{room.session}</p>
            <div className="mt-2.5 flex items-center justify-between border-t border-surface-border pt-2">
              <span className="text-[11px] text-slate-500">Queue: {room.waiting} patients waiting</span>
              <button className="text-[11px] font-semibold text-brand-cyan hover:underline">View Queue</button>
            </div>
          </div>
        ))}
      </div>
    </Card>
  );
}
