import { ClipboardCheck, Printer, CheckCircle2, ShieldAlert, ChevronDown } from "lucide-react";
import Card from "../Card";
import {
  selectedRxPatient,
  clinicalFlags,
  rxLineItems,
  rxVerifiedCount,
  thermalLabel,
} from "@/lib/pharmacy-data";

export default function PrescriptionDetail() {
  return (
    <Card
      icon={ClipboardCheck}
      iconClassName="bg-teal-50 text-brand-teal"
      title={selectedRxPatient.rxId}
      subtitle={`${selectedRxPatient.name} · ${selectedRxPatient.nhis}`}
      headerClassName="px-4 py-3"
      bodyClassName="p-4"
      action={
        <span className="rounded-full bg-status-green-bg px-2.5 py-1 text-[11px] font-semibold text-status-green">
          {rxVerifiedCount.verified}/{rxVerifiedCount.total} Items Verified
        </span>
      }
    >
      <div className="grid grid-cols-2 gap-2 rounded-lg border border-surface-border bg-slate-50 p-2.5 text-[11px] sm:grid-cols-4">
        <Info label="Date of Birth" value={selectedRxPatient.dob} />
        <Info label="Sex" value={selectedRxPatient.sex} />
        <Info label="Blood Group" value={selectedRxPatient.blood} />
        <Info label="Weight" value={selectedRxPatient.weight} />
      </div>

      <div className="mt-2 grid grid-cols-1 gap-1.5 sm:grid-cols-3">
        {clinicalFlags.map((flag) => (
          <div key={flag.id} className="flex items-center gap-1.5 rounded-lg border border-surface-border bg-white px-2.5 py-1.5">
            <ShieldAlert className="h-3.5 w-3.5 shrink-0 text-status-green" />
            <div className="leading-tight">
              <p className="text-[11px] font-bold text-slate-700">{flag.title}</p>
              <p className="text-[10px] text-slate-400">{flag.lines.join(" · ")}</p>
            </div>
          </div>
        ))}
      </div>

      <div className="mt-3 space-y-1.5">
        {rxLineItems.map((item) => (
          <div key={item.id} className="rounded-lg border border-surface-border bg-white px-3 py-2">
            <div className="flex flex-wrap items-start justify-between gap-2">
              <div>
                <p className="text-[12px] font-bold text-slate-800">{item.name}</p>
                <p className="text-[10px] text-slate-500">
                  {item.qty} · Copay: {item.copay} · {item.sig}
                </p>
              </div>
              {item.verified && (
                <span className="flex shrink-0 items-center gap-1 rounded-full bg-status-green-bg px-2 py-0.5 text-[10px] font-bold text-status-green">
                  <CheckCircle2 className="h-3 w-3" />
                  Verified
                </span>
              )}
            </div>
            <div className="mt-1 flex flex-wrap gap-x-3 gap-y-0.5 border-t border-surface-border pt-1 text-[10px] text-slate-400">
              <span>Batch: {item.batch}</span>
              <span>Exp: {item.exp}</span>
              <span>{item.location}</span>
              <span>{item.gtin}</span>
              <span>Stock: {item.stock}</span>
            </div>
          </div>
        ))}
      </div>

      <details className="mt-3 group rounded-lg border border-dashed border-surface-border bg-red-50 p-2.5">
        <summary className="flex cursor-pointer list-none items-center justify-between text-[11px] font-semibold text-slate-500">
          <span className="flex items-center gap-1.5">
            <Printer className="h-3.5 w-3.5" />
            Thermal Label Preview · {thermalLabel.device}
          </span>
          <ChevronDown className="h-3.5 w-3.5 transition-transform group-open:rotate-180" />
        </summary>
        <div className="mt-2 rounded-md border border-slate-300 bg-white p-2.5 font-mono text-[10px] leading-snug text-slate-700">
          <p className="text-center font-bold">{thermalLabel.hospitalName}</p>
          <p className="text-center">{thermalLabel.phone}</p>
          <p className="mt-1">{thermalLabel.patientLine}</p>
          <p className="mt-1">{thermalLabel.instructions}</p>
          <p className="mt-1">{thermalLabel.dispensed}</p>
          <p>{thermalLabel.dispenser}</p>
        </div>
      </details>

      <div className="mt-3 flex flex-wrap items-center justify-end gap-2">
        <button className="rounded-lg border border-surface-border px-4 py-2 text-xs font-semibold text-slate-500 hover:bg-slate-50">
          Flag for Pharmacist Review
        </button>
        <button className="rounded-lg bg-brand-teal px-4 py-2 text-xs font-semibold text-white hover:bg-teal-700">
          Print Label & Dispense
        </button>
      </div>
    </Card>
  );
}

function Info({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <p className="text-[10px] uppercase tracking-wide text-slate-400">{label}</p>
      <p className="font-semibold text-slate-700">{value}</p>
    </div>
  );
}
