import { ListFilter, Timer } from "lucide-react";
import Card from "../Card";
import { queueFilters, queueItems, type QueueStatus } from "@/lib/pharmacy-data";

const statusStyle: Record<QueueStatus, string> = {
  "Ready for Final Check": "bg-status-green-bg text-status-green",
  "STAT / Emergency": "bg-status-red-bg text-status-red",
  "Insurance Clearance": "bg-status-amber-bg text-status-amber",
  "Verification Passed": "bg-status-blue-bg text-status-blue",
};

export default function IngestionQueue() {
  return (
    <Card
      icon={ListFilter}
      iconClassName="bg-teal-50 text-brand-teal"
      title="Prescription Ingestion & Dispensing Queue"
      subtitle="Sorted by Clinical Priority & Wait Time"
      headerClassName="px-4 py-3"
      bodyClassName="p-4"
      action={
        <div className="flex items-center gap-1.5">
          {queueFilters.map((f) => (
            <button
              key={f.id}
              className={`rounded-md px-2.5 py-1 text-[11px] font-semibold ${
                f.active
                  ? "bg-brand-teal text-white"
                  : "bg-slate-100 text-slate-500 hover:bg-slate-200"
              }`}
            >
              {f.label} <span className="opacity-75">{f.count}</span>
            </button>
          ))}
        </div>
      }
    >
      <div className="space-y-2">
        {queueItems.map((item) => (
          <div
            key={item.id}
            className={`rounded-lg border px-3 py-2 ${
              item.selected
                ? "border-brand-teal bg-teal-50/40 ring-1 ring-brand-teal"
                : "border-surface-border bg-white"
            }`}
          >
            <div className="flex flex-wrap items-start justify-between gap-2">
              <div>
                <div className="flex items-center gap-2">
                  <span className="font-mono text-[11px] font-semibold text-slate-400">{item.rxId}</span>
                  <span
                    className={`rounded px-2 py-0.5 text-[10px] font-bold ${statusStyle[item.status]}`}
                  >
                    {item.status}
                  </span>
                </div>
                <p className="mt-1 text-sm font-bold text-slate-800">{item.patient}</p>
                <p className="text-[11px] text-slate-500">{item.location}</p>
                {item.detail && (
                  <p
                    className={`mt-1 text-[11px] font-medium ${
                      item.detailUrgent ? "text-status-red" : "text-slate-500"
                    }`}
                  >
                    {item.detail}
                  </p>
                )}
                {item.statusNote && (
                  <p className="mt-0.5 text-[11px] text-slate-400">{item.statusNote}</p>
                )}
              </div>
              <div className="text-right">
                <p className="text-[11px] text-slate-400">Prescriber: {item.prescriber}</p>
                {item.wait && (
                  <p className="mt-1 flex items-center justify-end gap-1 text-[11px] font-semibold text-slate-600">
                    <Timer className="h-3 w-3" />
                    {item.waitLabel} {item.wait}
                  </p>
                )}
                {item.itemsNote && (
                  <p className="mt-1 text-[11px] font-semibold text-brand-teal">{item.itemsNote}</p>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>
    </Card>
  );
}
