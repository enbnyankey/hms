import { AlertTriangle, Lock, Thermometer, DoorOpen } from "lucide-react";
import Card from "../Card";
import {
  lowStockAlerts,
  lowStockActionCount,
  controlledVault,
  coldChainLog,
  dispensaryWindow,
} from "@/lib/pharmacy-data";

export default function PharmacySidebar() {
  return (
    <div className="space-y-4">
      <Card
        icon={AlertTriangle}
        iconClassName="bg-status-red-bg text-status-red"
        title="Low-Stock Critical Alerts"
        subtitle={`${lowStockActionCount} items need reorder action`}
        headerClassName="px-4 py-3"
        bodyClassName="p-4"
      >
        <div className="space-y-2.5">
          {lowStockAlerts.map((item) => (
            <div key={item.id} className="rounded-lg border border-status-red-bg bg-status-red-bg/40 p-2.5">
              <div className="flex items-center justify-between">
                <p className="text-[11px] font-bold text-slate-800">{item.name}</p>
                <span className="text-[11px] font-extrabold text-status-red">
                  {item.qty} <span className="font-medium text-slate-400">{item.unit}</span>
                </span>
              </div>
              <p className="mt-0.5 text-[10px] text-slate-500">{item.threshold}</p>
              <div className="mt-1 flex items-center justify-between text-[10px] text-slate-400">
                <span>{item.supplierNote}</span>
                {item.poNote && <span className="font-semibold text-status-green">{item.poNote}</span>}
                {item.reorder && (
                  <button className="rounded bg-status-red px-2 py-0.5 text-[10px] font-semibold text-white">
                    Reorder
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      </Card>

      <Card
        icon={Lock}
        iconClassName="bg-slate-100 text-slate-600"
        title="Controlled Substance Vault"
        subtitle="Schedule II Narcotics Ledger"
        headerClassName="px-4 py-3"
        bodyClassName="p-4"
      >
        <div className="flex items-center justify-between">
          <p className="text-[11px] font-semibold text-slate-700">{controlledVault.drug}</p>
          <p className="text-lg font-extrabold text-slate-900">
            {controlledVault.qty}
            <span className="ml-1 text-[10px] font-semibold text-slate-400">{controlledVault.unit}</span>
          </p>
        </div>
        <p className="mt-2 text-[10px] leading-snug text-slate-500">{controlledVault.note}</p>
        <p className="mt-1.5 text-[10px] font-semibold text-slate-400">{controlledVault.witnesses}</p>
      </Card>

      <Card
        icon={Thermometer}
        iconClassName="bg-blue-50 text-status-blue"
        title="Cold Chain Monitoring"
        subtitle={coldChainLog.unit}
        headerClassName="px-4 py-3"
        bodyClassName="p-4"
      >
        <div className="flex items-center justify-between">
          <p className="text-[11px] text-slate-500">{coldChainLog.location}</p>
          <p className="text-lg font-extrabold text-status-blue">{coldChainLog.temp}</p>
        </div>
        <p className="mt-1.5 text-[10px] font-semibold text-status-green">{coldChainLog.status}</p>
      </Card>

      <Card
        icon={DoorOpen}
        iconClassName="bg-teal-50 text-brand-teal"
        title={dispensaryWindow.label}
        subtitle={dispensaryWindow.queueWaiting}
        headerClassName="px-4 py-3"
        bodyClassName="p-4"
      >
        <button className="w-full rounded-lg bg-brand-teal py-2 text-xs font-semibold text-white hover:bg-teal-700">
          {dispensaryWindow.actionLabel}
        </button>
      </Card>
    </div>
  );
}
