import { ScanLine, ExternalLink } from "lucide-react";
import { imagingOrders } from "@/lib/doctor-data";

export default function ImagingTracings() {
  return (
    <div className="rounded-xl border border-surface-border bg-white shadow-card">
      <div className="flex items-center justify-between gap-2 border-b border-surface-border px-5 py-4">
        <div className="flex items-center gap-2">
          <ScanLine className="h-4 w-4 text-slate-500" />
          <h2 className="text-sm font-bold text-slate-900">Imaging & Tracings</h2>
        </div>
        <ExternalLink className="h-3.5 w-3.5 text-slate-300" />
      </div>

      <div className="space-y-2.5 p-5">
        {imagingOrders.map((img) => (
          <div key={img.id} className="flex items-start justify-between gap-2 rounded-lg border border-surface-border p-3">
            <div>
              <p className="text-xs font-bold text-slate-800">{img.title}</p>
              <p className="mt-0.5 text-[11px] text-slate-400">{img.detail}</p>
            </div>
            <span className="shrink-0 rounded bg-slate-100 px-2 py-0.5 text-[10px] font-bold text-slate-500">
              {img.tag}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}
