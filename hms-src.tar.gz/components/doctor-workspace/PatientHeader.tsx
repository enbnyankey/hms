import { Printer, FlaskConical, BedDouble, CheckCircle2 } from "lucide-react";
import { activePatient } from "@/lib/doctor-data";

export default function PatientHeader() {
  return (
    <div className="rounded-xl border border-surface-border bg-white p-5 shadow-card">
      <div className="flex flex-wrap items-start justify-between gap-4">
        <div className="flex items-start gap-4">
          <div className="flex h-16 w-16 shrink-0 items-center justify-center rounded-full bg-slate-800 text-lg font-bold text-white">
            {activePatient.initials}
          </div>
          <div>
            <div className="flex flex-wrap items-baseline gap-2">
              <h1 className="text-xl font-extrabold text-slate-900">{activePatient.name}</h1>
              <span className="text-xs font-medium text-slate-400">
                {activePatient.sex}, {activePatient.age} yrs ({activePatient.dob})
              </span>
            </div>
            <div className="mt-1.5">
              <span className="inline-flex items-center gap-1.5 rounded-full bg-status-red-bg px-2.5 py-1 text-[11px] font-bold text-status-red">
                <span className="h-1.5 w-1.5 rounded-full bg-status-red" />
                {activePatient.priority} · {activePatient.priorityReason}
              </span>
            </div>
            <p className="mt-2 text-xs text-slate-500">
              <span className="font-semibold text-slate-600">MRN: {activePatient.mrn}</span>
              <span className="mx-2 text-slate-300">·</span>
              NHIS: {activePatient.nhis}
              <span className="mx-2 text-slate-300">·</span>
              Blood Group: <span className="font-semibold text-slate-700">{activePatient.bloodGroup}</span>
            </p>
            <p className="mt-0.5 text-xs text-slate-400">
              Encounter: <span className="text-slate-600">{activePatient.encounter}</span>
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button className="flex items-center gap-1.5 rounded-md border border-surface-border bg-white px-3 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-50">
            <Printer className="h-3.5 w-3.5" />
            Print Summary
          </button>
          <button className="flex items-center gap-1.5 rounded-md border border-surface-border bg-white px-3 py-2 text-xs font-semibold text-brand-cyan hover:bg-slate-50">
            <FlaskConical className="h-3.5 w-3.5" />
            Rapid STAT Lab
          </button>
          <button className="flex items-center gap-1.5 rounded-md bg-status-red px-3 py-2 text-xs font-semibold text-white hover:bg-red-700">
            <BedDouble className="h-3.5 w-3.5" />
            Admit to Ward
          </button>
          <button className="flex items-center gap-1.5 rounded-md bg-brand-teal px-3 py-2 text-xs font-semibold text-white hover:bg-teal-700">
            <CheckCircle2 className="h-3.5 w-3.5" />
            Finish Consultation
          </button>
        </div>
      </div>
    </div>
  );
}
