import { ListChecks } from "lucide-react";
import Card from "@/components/Card";
import { problemList, type ProblemListItem } from "@/lib/doctor-data";

const toneBadge: Record<ProblemListItem["statusTone"], string> = {
  danger: "bg-status-red-bg text-status-red",
  warning: "bg-status-amber-bg text-status-amber",
  info: "bg-status-blue-bg text-status-blue",
};

export default function ProblemList() {
  return (
    <Card icon={ListChecks} iconClassName="bg-slate-100 text-slate-500" title="Active Problem List">
      <div className="space-y-3">
        {problemList.map((item) => (
          <div key={item.id} className="rounded-lg border border-surface-border p-3">
            <div className="flex items-start justify-between gap-2">
              <p className="text-xs font-bold text-slate-800">{item.title}</p>
              <span className={`shrink-0 rounded-full px-2 py-0.5 text-[10px] font-bold ${toneBadge[item.statusTone]}`}>
                {item.status}
              </span>
            </div>
            <p className="mt-1 text-[11px] text-slate-400">{item.detail}</p>
          </div>
        ))}
      </div>
    </Card>
  );
}
