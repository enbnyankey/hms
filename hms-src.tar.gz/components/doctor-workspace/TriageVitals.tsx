import { HeartPulse, CheckCircle2 } from "lucide-react";
import {
  triageVitalsMeta,
  bloodPressure,
  bpTrend,
  bpTrendDrift,
  vitalStats,
  bodyStats,
} from "@/lib/doctor-data";

const CHART_WIDTH = 260;
const CHART_HEIGHT = 56;
const PADDING_X = 4;

function BpTrendChart() {
  const values = bpTrend.map((p) => p.value);
  const min = Math.min(...values) - 6;
  const max = Math.max(...values) + 6;
  const span = max - min || 1;
  const step = (CHART_WIDTH - PADDING_X * 2) / (bpTrend.length - 1);

  const points = bpTrend.map((p, i) => {
    const x = PADDING_X + step * i;
    const y = CHART_HEIGHT - ((p.value - min) / span) * CHART_HEIGHT;
    return { x, y, ...p };
  });

  const path = points.map((p, i) => `${i === 0 ? "M" : "L"} ${p.x} ${p.y}`).join(" ");

  return (
    <svg
      viewBox={`0 0 ${CHART_WIDTH} ${CHART_HEIGHT}`}
      className="h-14 w-full"
      role="img"
      aria-label={`Blood pressure trend across four visits, rising from ${values[0]} to ${values[values.length - 1]}`}
    >
      <path d={path} fill="none" stroke="#dc2626" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" />
      {points.map((p, i) => (
        <circle
          key={p.label}
          cx={p.x}
          cy={p.y}
          r={i === points.length - 1 ? 4 : 3}
          fill={i === points.length - 1 ? "#dc2626" : "#ffffff"}
          stroke="#dc2626"
          strokeWidth={2}
        />
      ))}
    </svg>
  );
}

export default function TriageVitals() {
  return (
    <div className="rounded-xl border border-surface-border bg-white shadow-card">
      <div className="flex items-center justify-between border-b border-surface-border px-5 py-4">
        <div className="flex items-center gap-2">
          <HeartPulse className="h-4 w-4 text-brand-cyan" />
          <h2 className="text-sm font-bold text-slate-900">Triage Vitals</h2>
        </div>
        <span className="text-[11px] font-medium text-slate-400">{triageVitalsMeta.time}</span>
      </div>

      <div className="px-5 pt-3">
        <p className="flex items-center gap-1 text-[11px] text-slate-400">
          {triageVitalsMeta.recordedBy}
          <CheckCircle2 className="h-3 w-3 text-status-green" />
        </p>
      </div>

      <div className="p-5 pt-3">
        <div className="rounded-lg border border-red-100 bg-status-red-bg p-4">
          <div className="flex items-start justify-between gap-2">
            <p className="text-[11px] font-bold uppercase leading-snug tracking-wide text-status-red">
              Blood Pressure (Urgent)
            </p>
            <span className="shrink-0 whitespace-nowrap rounded-full bg-status-red px-2 py-1 text-[9px] font-bold leading-none text-white">
              {bloodPressure.stageLabel.toUpperCase()}
            </span>
          </div>
          <p className="mt-1.5 text-3xl font-extrabold text-status-red">
            {bloodPressure.systolic} / {bloodPressure.diastolic}{" "}
            <span className="text-sm font-semibold text-status-red/70">mmHg</span>
          </p>
          <p className="mt-1 text-[11px] text-status-red/80">
            MAP: {bloodPressure.map} mmHg · Target: {bloodPressure.target}
          </p>
        </div>

        <div className="mt-4 grid grid-cols-2 gap-3">
          {vitalStats.map((stat) => (
            <div key={stat.id} className="rounded-lg border border-surface-border p-3">
              <p className="text-[10px] font-semibold uppercase tracking-wide text-slate-400">{stat.label}</p>
              <p className="mt-1 text-lg font-extrabold text-slate-900">
                {stat.value} <span className="text-xs font-medium text-slate-400">{stat.unit}</span>
              </p>
              <p className="text-[11px] text-slate-400">{stat.note}</p>
            </div>
          ))}
        </div>

        <div className="mt-3 grid grid-cols-2 gap-3">
          {bodyStats.map((stat) => (
            <div key={stat.id} className="rounded-lg border border-surface-border p-3">
              <p className="text-[10px] font-semibold uppercase tracking-wide text-slate-400">{stat.label}</p>
              <p className={`mt-1 text-lg font-extrabold ${stat.valueClass ?? "text-slate-900"}`}>
                {stat.value} <span className="text-xs font-medium text-slate-400">{stat.unit}</span>
              </p>
              <p className="text-[11px] text-slate-400">{stat.note}</p>
            </div>
          ))}
        </div>

        <div className="mt-4 rounded-lg border border-surface-border p-3">
          <div className="flex items-center justify-between">
            <p className="text-xs font-bold text-slate-700">BP Trend (Last 4 Visits)</p>
            <span className="text-[11px] font-bold text-status-red">{bpTrendDrift}</span>
          </div>
          <div className="mt-2">
            <BpTrendChart />
          </div>
          <div className="mt-1 flex justify-between text-[10px] text-slate-400">
            {bpTrend.map((p) => (
              <span key={p.label} className={p.label === "Today" ? "font-bold text-status-red" : ""}>
                {p.label}
                <br />({p.value})
              </span>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
