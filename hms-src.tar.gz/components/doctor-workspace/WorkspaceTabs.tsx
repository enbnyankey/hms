import { Activity } from "lucide-react";
import { workspaceTabs } from "@/lib/doctor-data";

export default function WorkspaceTabs() {
  return (
    <div className="mt-4 flex items-center gap-1 overflow-x-auto rounded-xl border border-surface-border bg-white p-1.5 shadow-card">
      {workspaceTabs.map((tab) => (
        <button
          key={tab.id}
          className={`flex shrink-0 items-center gap-2 rounded-lg px-3.5 py-2 text-xs font-semibold transition-colors ${
            tab.active
              ? "bg-status-blue-bg text-brand-cyan"
              : "text-slate-500 hover:bg-slate-50"
          }`}
        >
          {tab.label}
          {tab.active && <span className="h-1.5 w-1.5 rounded-full bg-brand-cyan" />}
          {typeof tab.count === "number" && (
            <span className="flex h-4 w-4 items-center justify-center rounded-full bg-brand-cyan text-[10px] font-bold text-white">
              {tab.count}
            </span>
          )}
        </button>
      ))}
      <span className="ml-auto flex shrink-0 items-center px-3 text-slate-300">
        <Activity className="h-4 w-4" />
      </span>
    </div>
  );
}
