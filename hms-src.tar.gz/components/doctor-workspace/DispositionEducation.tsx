import { CalendarClock, CheckCircle2, AlertTriangle } from "lucide-react";
import { disposition, patientDirectives } from "@/lib/doctor-data";

export default function DispositionEducation() {
  return (
    <div className="rounded-xl border border-surface-border bg-white shadow-card">
      <div className="flex items-center gap-2 border-b border-surface-border px-5 py-4">
        <CalendarClock className="h-4 w-4 text-slate-500" />
        <h2 className="text-sm font-bold text-slate-900">Disposition & Education</h2>
      </div>

      <div className="p-5">
        <p className="text-[11px] font-bold uppercase tracking-wide text-slate-400">{disposition.reviewLabel}</p>
        <p className="mt-1 text-sm font-bold text-slate-800">{disposition.reviewWhen}</p>
        <p className="text-[11px] text-slate-400">{disposition.reviewDetail}</p>

        <p className="mt-4 text-[11px] font-bold uppercase tracking-wide text-slate-400">Patient Directives:</p>
        <ul className="mt-2 space-y-2">
          {patientDirectives.map((d) => (
            <li key={d.id} className="flex items-start gap-2 text-[11px] leading-snug">
              {d.tone === "ok" ? (
                <CheckCircle2 className="mt-0.5 h-3.5 w-3.5 shrink-0 text-status-green" />
              ) : (
                <AlertTriangle className="mt-0.5 h-3.5 w-3.5 shrink-0 text-status-red" />
              )}
              <span className={d.tone === "warning" ? "font-semibold text-status-red" : "text-slate-600"}>
                {d.text}
              </span>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}
