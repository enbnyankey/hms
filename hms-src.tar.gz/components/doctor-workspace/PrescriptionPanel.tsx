import { FilePenLine, ShieldCheck, Trash2, Plus } from "lucide-react";
import { prescriptions, rxCrossCheckNote } from "@/lib/doctor-data";

export default function PrescriptionPanel() {
  return (
    <div className="rounded-xl border border-surface-border bg-white shadow-card">
      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-surface-border px-5 py-4">
        <div className="flex items-center gap-2">
          <FilePenLine className="h-4 w-4 text-slate-500" />
          <h2 className="text-sm font-bold text-slate-900">Electronic Prescription (e-Rx)</h2>
        </div>
        <span className="flex items-center gap-1.5 rounded-full bg-status-green-bg px-2.5 py-1 text-[11px] font-semibold text-status-green">
          <ShieldCheck className="h-3.5 w-3.5" />
          NHIS Formulary Compliant
        </span>
      </div>

      <div className="space-y-3 p-5">
        {prescriptions.map((rx) => (
          <div key={rx.id} className="rounded-lg border border-surface-border p-3.5">
            <div className="flex flex-wrap items-start justify-between gap-2">
              <div>
                <p className="text-xs font-bold text-slate-800">{rx.drug}</p>
                <p className="text-[11px] text-slate-400">{rx.cost}</p>
              </div>
              <div className="flex items-center gap-2">
                <span className="rounded-full bg-teal-50 px-2 py-0.5 text-[10px] font-semibold text-brand-teal">
                  {rx.tag}
                </span>
                <button className="text-slate-300 hover:text-status-red">
                  <Trash2 className="h-3.5 w-3.5" />
                </button>
              </div>
            </div>
            <p className="mt-1.5 text-[11px] text-slate-500">
              Dosage: {rx.dosage} · Duration: {rx.duration}
            </p>
          </div>
        ))}

        <div className="flex flex-wrap items-center justify-between gap-3 rounded-lg border border-surface-border bg-slate-50 p-3">
          <p className="flex items-center gap-1.5 text-[11px] text-slate-500">
            <ShieldCheck className="h-3.5 w-3.5 shrink-0 text-status-green" />
            {rxCrossCheckNote}
          </p>
          <button className="flex shrink-0 items-center gap-1.5 rounded-md bg-brand-cyan px-3 py-2 text-xs font-semibold text-white hover:bg-cyan-800">
            <Plus className="h-3.5 w-3.5" />
            Add Drug to Rx
          </button>
        </div>
      </div>
    </div>
  );
}
