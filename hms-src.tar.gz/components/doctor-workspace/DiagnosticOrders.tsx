import { ClipboardList, Check } from "lucide-react";
import { diagnosticOrders, priorLabs, priorLabsDate, type DiagnosticOrder } from "@/lib/doctor-data";

const tagTone: Record<DiagnosticOrder["tagTone"], string> = {
  danger: "bg-status-red text-white",
  warning: "bg-status-amber text-white",
  neutral: "bg-slate-100 text-slate-500",
};

export default function DiagnosticOrders() {
  return (
    <div className="rounded-xl border border-surface-border bg-white shadow-card">
      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-surface-border px-5 py-4">
        <div className="flex items-center gap-2">
          <ClipboardList className="h-4 w-4 text-slate-500" />
          <h2 className="text-sm font-bold text-slate-900">Diagnostic Orders</h2>
        </div>
        <span className="rounded-full bg-status-red-bg px-2.5 py-1 text-[10px] font-bold text-status-red">
          STAT DISPATCH
        </span>
      </div>

      <div className="space-y-2.5 p-5">
        {diagnosticOrders.map((order) => (
          <div key={order.id} className="flex items-start gap-2.5 rounded-lg border border-surface-border p-3">
            <span className="mt-0.5 flex h-4 w-4 shrink-0 items-center justify-center rounded border border-status-green bg-status-green-bg text-status-green">
              {order.checked && <Check className="h-3 w-3" strokeWidth={3} />}
            </span>
            <div className="min-w-0 flex-1">
              <p className="text-xs font-bold text-slate-800">{order.title}</p>
              <p className="text-[11px] text-slate-400">{order.detail}</p>
            </div>
            <span className={`shrink-0 rounded px-2 py-0.5 text-[10px] font-bold ${tagTone[order.tagTone]}`}>
              {order.tag}
            </span>
          </div>
        ))}

        <div className="rounded-lg border border-surface-border bg-slate-50 p-3">
          <p className="text-[11px] font-bold text-slate-600">Recent Prior Labs ({priorLabsDate})</p>
          <div className="mt-2 grid grid-cols-2 gap-3">
            {priorLabs.map((lab) => (
              <div key={lab.id}>
                <p className="text-[10px] font-semibold uppercase tracking-wide text-slate-400">{lab.label}</p>
                <p className="text-sm font-bold text-slate-800">{lab.value}</p>
                <p className="text-[10px] text-status-green">{lab.note}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
