import { Stamp, HelpCircle, Plus } from "lucide-react";
import { diagnoses } from "@/lib/doctor-data";

export default function DiagnosisFormulation() {
  return (
    <div className="rounded-xl border border-surface-border bg-white shadow-card">
      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-surface-border px-5 py-4">
        <div className="flex items-center gap-2">
          <Stamp className="h-4 w-4 text-slate-500" />
          <h2 className="text-sm font-bold text-slate-900">Diagnosis Formulation (ICD-11 Standardized)</h2>
        </div>
        <button className="flex items-center gap-1 text-[11px] font-semibold text-brand-cyan hover:underline">
          <Plus className="h-3.5 w-3.5" />
          Add Secondary / Differential
        </button>
      </div>

      <div className="space-y-3 p-5">
        {diagnoses.map((dx) => (
          <div key={dx.id} className="flex items-start gap-3 rounded-lg border border-surface-border p-3.5">
            {dx.kind === "PRIMARY" ? (
              <span className="shrink-0 rounded bg-status-red px-2 py-1 text-[10px] font-bold text-white">
                PRIMARY
              </span>
            ) : (
              <span className="shrink-0 rounded bg-slate-100 px-2 py-1 text-[10px] font-bold text-slate-500">
                DIFFERENTIAL
              </span>
            )}
            <div className="flex-1">
              <p className="text-xs font-bold text-slate-800">
                {dx.code} {dx.title}
              </p>
              <p className="mt-0.5 text-[11px] text-slate-400">{dx.detail}</p>
            </div>
            {dx.kind === "DIFFERENTIAL" && (
              <HelpCircle className="mt-0.5 h-3.5 w-3.5 shrink-0 text-slate-300" />
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
