import { NotebookText, Mic } from "lucide-react";
import { chiefComplaint, hpiAuthor, hpiNotes, objectiveExam } from "@/lib/doctor-data";

export default function ConsultationPanel() {
  return (
    <div className="rounded-xl border border-surface-border bg-white shadow-card">
      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-surface-border px-5 py-4">
        <div className="flex items-center gap-2">
          <NotebookText className="h-4 w-4 text-slate-500" />
          <h2 className="text-sm font-bold text-slate-900">Active Consultation & Subjective HPI</h2>
        </div>
        <button className="flex items-center gap-1.5 rounded-md border border-surface-border px-2.5 py-1.5 text-[11px] font-semibold text-brand-cyan hover:bg-slate-50">
          <Mic className="h-3.5 w-3.5" />
          Voice Dictation Ready
        </button>
      </div>

      <div className="p-5">
        <p className="text-[11px] font-bold uppercase tracking-wide text-slate-400">
          Chief Complaint (Patient&apos;s Own Words)
        </p>
        <blockquote className="mt-2 rounded-lg border border-surface-border bg-slate-50 p-3.5 text-sm italic leading-relaxed text-slate-700">
          &ldquo;{chiefComplaint}&rdquo;
        </blockquote>

        <div className="mt-5 flex flex-wrap items-center justify-between gap-2">
          <p className="text-[11px] font-bold uppercase tracking-wide text-slate-400">
            History of Presenting Illness (HPI) Notes
          </p>
          <span className="text-[11px] font-semibold text-brand-cyan">{hpiAuthor}</span>
        </div>
        <p className="mt-2 text-sm leading-relaxed text-slate-600">{hpiNotes}</p>

        <p className="mt-5 text-[11px] font-bold uppercase tracking-wide text-slate-400">
          Objective Physical Examination
        </p>
        <div className="mt-2 grid grid-cols-1 gap-2 2xl:grid-cols-3">
          {objectiveExam.map((exam) => (
            <div key={exam.id} className="min-w-0 rounded-lg border border-surface-border p-2.5">
              <p className="text-xs font-bold text-slate-800">{exam.system}</p>
              <p className="mt-1 text-[11px] leading-snug text-slate-500 break-words">{exam.findings}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
