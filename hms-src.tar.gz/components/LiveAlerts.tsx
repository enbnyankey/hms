import { Radio } from "lucide-react";
import Card from "./Card";
import { liveAlerts, type AlertSeverity } from "@/lib/mock-data";

const severityStyles: Record<AlertSeverity, { border: string; bg: string; text: string; button: string }> = {
  critical: {
    border: "border-red-200",
    bg: "bg-status-red-bg",
    text: "text-status-red",
    button: "bg-status-red text-white hover:bg-red-700",
  },
  warning: {
    border: "border-orange-200",
    bg: "bg-status-orange-bg",
    text: "text-status-orange",
    button: "bg-status-orange text-white hover:bg-orange-700",
  },
  info: {
    border: "border-blue-200",
    bg: "bg-status-blue-bg",
    text: "text-status-blue",
    button: "border border-surface-border bg-white text-slate-600 hover:bg-slate-50",
  },
};

export default function LiveAlerts() {
  const criticalCount = liveAlerts.filter((a) => a.severity === "critical").length;

  return (
    <Card
      icon={Radio}
      iconClassName="bg-status-red-bg text-status-red"
      title="Live Clinical Dispatch & Panic Alerts"
      subtitle="Real-time telemetry, panic lab notifications, and pharmacy critical approvals"
      action={
        <div className="flex items-center gap-2">
          <span className="flex items-center gap-1.5 rounded-full bg-status-red-bg px-2.5 py-1 text-[11px] font-semibold text-status-red">
            <span className="h-1.5 w-1.5 rounded-full bg-status-red" />
            {criticalCount} Panic Values Detected
          </span>
          <button className="rounded-full border border-surface-border px-2.5 py-1 text-[11px] font-semibold text-slate-500 hover:bg-slate-50">
            Silence Telemetry Tone
          </button>
        </div>
      }
    >
      <div className="grid gap-3 lg:grid-cols-3">
        {liveAlerts.map((alert) => {
          const style = severityStyles[alert.severity];
          return (
            <div key={alert.id} className={`rounded-lg border p-3 ${style.border} ${style.bg}`}>
              <div className="flex items-center justify-between">
                <span className={`text-[11px] font-bold uppercase tracking-wide ${style.text}`}>
                  {alert.title}
                </span>
                <span className="text-[10px] text-slate-400">{alert.time}</span>
              </div>
              <p className="mt-1.5 text-xs leading-snug text-slate-700">{alert.detail}</p>
              <p className="mt-1.5 text-[11px] text-slate-500">{alert.meta}</p>
              <button className={`mt-3 w-full rounded-md py-1.5 text-[11px] font-semibold ${style.button}`}>
                {alert.actionLabel}
              </button>
            </div>
          );
        })}
      </div>
    </Card>
  );
}
