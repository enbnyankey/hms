import { CalendarDays, Building2, Printer, Download, Clock } from "lucide-react";
import { facility } from "@/lib/mock-data";

export default function DashboardHeader() {
  return (
    <div className="mb-6 flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between">
      <div>
        <div className="mb-2 inline-flex items-center gap-2 rounded-full bg-slate-100 px-3 py-1 text-[11px] font-semibold text-slate-500">
          {facility.tier}
        </div>
        <h1 className="text-3xl font-extrabold tracking-tight text-slate-900">
          Executive Hospital Operations
        </h1>
        <p className="mt-1 max-w-2xl text-sm text-slate-500">{facility.region}</p>
      </div>

      <div className="flex flex-wrap items-center gap-2">
        <div className="flex items-center gap-1.5 rounded-md border border-surface-border bg-white px-3 py-2 text-xs font-medium text-slate-600">
          <CalendarDays className="h-3.5 w-3.5 text-slate-400" />
          {facility.date}
        </div>
        <div className="flex items-center gap-1.5 rounded-md border border-surface-border bg-white px-3 py-2 text-xs font-medium text-slate-600">
          <Building2 className="h-3.5 w-3.5 text-slate-400" />
          Main Teaching Hospital (Accra)
        </div>
        <div className="flex items-center gap-1.5 rounded-md border border-surface-border bg-white px-3 py-2 text-xs font-medium text-slate-600">
          <Clock className="h-3.5 w-3.5 text-slate-400" />
          {facility.shiftLabel}
        </div>
        <button className="flex items-center gap-1.5 rounded-md border border-surface-border bg-white px-3 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-50">
          <Printer className="h-3.5 w-3.5" />
          Print Census
        </button>
        <button className="flex items-center gap-1.5 rounded-md bg-brand-cyan px-3 py-2 text-xs font-semibold text-white hover:bg-cyan-800">
          <Download className="h-3.5 w-3.5" />
          Export Analytics
        </button>
      </div>
    </div>
  );
}
