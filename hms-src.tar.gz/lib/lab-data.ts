// Mock data for the Laboratory & Diagnostic Hub.

export const labHeader = {
  title: "Central Pathology & Clinical Chemistry",
  block: "LAB BLOCK 2",
  supervisor: "Dr. Kwabena Frimpong, PhD, FWAPCMLS",
  role: "Shift Supervisor",
  lisStatus: "LIS Interfaced",
};

export type LabKpi = {
  id: string;
  label: string;
  value: string;
  unit?: string;
  note: string;
  tone?: "danger" | "success";
};

export const labKpis: LabKpi[] = [
  { id: "pending", label: "Pending Accession", value: "22", unit: "Specimens", note: "14 Blood · 5 Urine · 3 CSF" },
  { id: "running", label: "In-Analyzer Run", value: "54", unit: "Tests Active", note: "Cobas 6000 & Sysmex XN" },
  { id: "panic", label: "Critical / Panic Values", value: "3", unit: "Calls Pending", note: "Requires Physician Readback", tone: "danger" },
  { id: "tat", label: "TAT Compliance (STAT)", value: "94.8%", unit: "Target <45m", note: "Avg: 31 mins benchmark", tone: "success" },
];

export type QueueTab = { id: string; label: string; count: number; active?: boolean };

export const queueTabs: QueueTab[] = [
  { id: "all", label: "All", count: 76, active: true },
  { id: "stat", label: "STAT", count: 9 },
  { id: "chem", label: "Chemistry", count: 32 },
];

export type SpecimenStatus = "Verification" | "STAT Run" | "Gram (-) Bacilli" | "Centrifuge Rack 3";

export type SpecimenItem = {
  id: string;
  specId: string;
  status: SpecimenStatus;
  statusTone: "blue" | "red" | "amber" | "slate";
  urgent?: boolean;
  patient: string;
  detail: string;
  containerDot: string;
  container: string;
  testOrder: string;
  selected?: boolean;
};

export const specimenItems: SpecimenItem[] = [
  {
    id: "s1",
    specId: "#SP-2024-8841-CHM",
    status: "Verification",
    statusTone: "blue",
    patient: "Kwame Boateng",
    detail: "54M · MRN #GH-2024-8841 · Ward A (Bed A-12)",
    containerDot: "bg-amber-400",
    container: "Serum Gel (SST Gold)",
    testOrder: "E/U/Cr + Trop-I",
    selected: true,
  },
  {
    id: "s2",
    specId: "#SP-2024-9102-HEM",
    status: "STAT Run",
    statusTone: "red",
    urgent: true,
    patient: "Kofi Mensah Addo",
    detail: "38M · Trauma Resus Bay 1 · Emergency",
    containerDot: "bg-purple-500",
    container: "EDTA Lavender Top",
    testOrder: "FBC + Crossmatch (4U)",
  },
  {
    id: "s3",
    specId: "#SP-2024-9088-MB",
    status: "Gram (-) Bacilli",
    statusTone: "amber",
    patient: "Akua Darko",
    detail: "62F · ICU Bed E-02 · Sepsis Screen",
    containerDot: "bg-status-green",
    container: "BactEC",
    testOrder: "Blood Culture & AST",
  },
  {
    id: "s4",
    specId: "#SP-2024-9044-CHM",
    status: "Centrifuge Rack 3",
    statusTone: "slate",
    patient: "Baby Kwesi (Neonatal)",
    detail: "4 Days · NICU Cot 07 · Phototherapy",
    containerDot: "bg-amber-400",
    container: "Microtainer Amber",
    testOrder: "Total & Direct Bilirubin",
  },
];

// --- Selected specimen detail ------------------------------------------------

export const selectedSpecimen = {
  patient: "Kwame Boateng",
  age: "54 yrs",
  sex: "Male",
  specId: "#SP-2024-8841-CHM",
  specType: "CHM",
  mrn: "GH-2024-8841",
  ward: "Block A",
  bed: "12",
  consultant: "Dr. Kobina Asadu",
  collection: "08:35 GMT",
  analyzer: "Roche Cobas 6000 (09:05)",
};

export type ClinicalFlagTone = "normal" | "high" | "low" | "critical";

export type AnalyteRow = {
  id: string;
  name: string;
  value: string;
  unit: string;
  range: string;
  flag: string;
  flagTone: ClinicalFlagTone;
};

export const analyteRows: AnalyteRow[] = [
  { id: "na", name: "Sodium (Na⁺)", value: "139.0", unit: "mmol/L", range: "135.0 – 145.0", flag: "Normal", flagTone: "normal" },
  { id: "k", name: "Potassium (K⁺)", value: "4.4", unit: "mmol/L", range: "3.5 – 5.0", flag: "Normal", flagTone: "normal" },
  { id: "cl", name: "Chloride (Cl⁻)", value: "102.0", unit: "mmol/L", range: "98.0 – 107.0", flag: "Normal", flagTone: "normal" },
  { id: "bun", name: "Urea Nitrogen (BUN)", value: "6.8", unit: "mmol/L", range: "2.5 – 7.5", flag: "Normal", flagTone: "normal" },
  { id: "creat", name: "Serum Creatinine", value: "104.0", unit: "μmol/L", range: "62.0 – 106.0", flag: "High-Normal", flagTone: "high" },
  { id: "egfr", name: "eGFR (CKD-EPI) [CALC]", value: "74.0", unit: "mL/min/1.73m²", range: "> 90.0", flag: "Stage 2 / Mild", flagTone: "low" },
  { id: "trop", name: "hs-Troponin I (hsTnI)", value: "12.4", unit: "ng/L", range: "< 14.0", flag: "Non-Ischemic, Rule-Out", flagTone: "normal" },
];

export const validationSignoff = {
  timestamp: "09:28:44 GMT",
  note: "Cardiac biomarkers non-elevated (hs-cTnI 12.4 ng/L); rule-out acute myocardial injury protocol satisfied. Mild renal functional alteration consistent with reported hypertension history. Delta check acceptable against prior admission values.",
};

// --- Right column ------------------------------------------------------------------

export type Analyzer = {
  id: string;
  name: string;
  desc: string;
  online: boolean;
  note?: string;
  status?: string;
  progressLabel?: string;
  progressPct?: number;
  alert?: string;
};

export const analyzers: Analyzer[] = [
  {
    id: "cobas",
    name: "Roche Cobas 6000",
    desc: "Clinical Chemistry & Immuno",
    online: true,
    note: "QC: Within 1.5 SD",
    status: "Ready (Idle 2m)",
  },
  {
    id: "sysmex",
    name: "Sysmex XN-1000",
    desc: "Automated Hematology Analyzer",
    online: true,
    progressLabel: "Reagents: 78%",
    progressPct: 78,
    status: "4 Tests in Rack",
  },
  {
    id: "bactec",
    name: "BD BactEC™ FX",
    desc: "Continuous Blood Culture Module",
    online: true,
    note: "Bottles: 24 Loaded",
    alert: "1 Positive Flag",
  },
];

export const analyzersOnlineCount = 3;

export type PanicCall = {
  id: string;
  time: string;
  state: "Verified" | "Dialing";
  ward: string;
  detail: string;
  note: string;
  actionLabel?: string;
};

export const panicCalls: PanicCall[] = [
  {
    id: "p1",
    time: "09:15 GMT",
    state: "Verified",
    ward: "Male Ward A",
    detail: "MRN #90214 · K⁺ = 6.8 mmol/L (Severe)",
    note: "Dr. Mensah read-back confirmed.",
  },
  {
    id: "p2",
    time: "09:22 GMT",
    state: "Dialing",
    ward: "Trauma Bay",
    detail: "MRN #9102 · Hemoglobin = 4.8 g/dL",
    note: "",
    actionLabel: "Connect Duty Physician",
  },
];

export const accreditation = {
  note: "Korle-Bu Central Diagnostic Network is ISO 15189:2022 compliant and synchronized with West African Health Organization (WAHO) Laboratory Quality Surveillance.",
};
