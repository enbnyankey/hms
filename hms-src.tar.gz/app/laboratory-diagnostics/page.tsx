import LabHeader from "@/components/lab/LabHeader";
import LabKpis from "@/components/lab/LabKpis";
import AccessioningQueue from "@/components/lab/AccessioningQueue";
import SpecimenDetail from "@/components/lab/SpecimenDetail";
import LabSidebar from "@/components/lab/LabSidebar";

export default function LaboratoryDiagnosticsPage() {
  return (
    <div>
      <LabHeader />

      <div className="mt-4">
        <LabKpis />
      </div>

      <div className="mt-4 grid grid-cols-1 gap-4 lg:grid-cols-[280px_1fr_280px]">
        <AccessioningQueue />
        <SpecimenDetail />
        <LabSidebar />
      </div>
    </div>
  );
}
