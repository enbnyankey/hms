import WardHeader from "@/components/ward-bed-manager/WardHeader";
import CensusKpis from "@/components/ward-bed-manager/CensusKpis";
import WardFilterBar from "@/components/ward-bed-manager/WardFilterBar";
import IcuWard from "@/components/ward-bed-manager/IcuWard";
import MaleWard from "@/components/ward-bed-manager/MaleWard";
import FemaleWard from "@/components/ward-bed-manager/FemaleWard";
import AdmissionsQueue from "@/components/ward-bed-manager/AdmissionsQueue";
import InfectionControl from "@/components/ward-bed-manager/InfectionControl";
import NursingRotaTable from "@/components/ward-bed-manager/NursingRotaTable";

export default function WardBedManagerPage() {
  return (
    <div>
      <WardHeader />
      <CensusKpis />
      <WardFilterBar />

      <div className="mt-5 grid grid-cols-1 gap-5 lg:grid-cols-[1fr_360px]">
        <div className="space-y-5">
          <IcuWard />
          <MaleWard />
        </div>

        <div className="space-y-5">
          <AdmissionsQueue />
          <InfectionControl />
          <FemaleWard />
        </div>
      </div>

      <div className="mt-5">
        <NursingRotaTable />
      </div>
    </div>
  );
}
