import BillingHeader from "@/components/billing/BillingHeader";
import BillingKpis from "@/components/billing/BillingKpis";
import NhisBatchCard from "@/components/billing/NhisBatchCard";
import InvoiceTable from "@/components/billing/InvoiceTable";
import PatientPaymentPanel from "@/components/billing/PatientPaymentPanel";

export default function BillingClaimsPage() {
  return (
    <div>
      <BillingHeader />
      <BillingKpis />
      <NhisBatchCard />

      <div className="mt-5 grid grid-cols-1 gap-5 lg:grid-cols-[1fr_400px]">
        <InvoiceTable />
        <PatientPaymentPanel />
      </div>
    </div>
  );
}
