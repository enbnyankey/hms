import PlaceholderPage from "@/components/PlaceholderPage";
import { UserPlus } from "lucide-react";

export default function Page() {
  return (
    <PlaceholderPage
      icon={UserPlus}
      title="Patient Registry"
      description="New patient registration, demographics, NHIS verification, and master patient index search."
    />
  );
}
