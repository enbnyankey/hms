import PatientHeader from "@/components/doctor-workspace/PatientHeader";
import AlertsRow from "@/components/doctor-workspace/AlertsRow";
import WorkspaceTabs from "@/components/doctor-workspace/WorkspaceTabs";
import TriageVitals from "@/components/doctor-workspace/TriageVitals";
import ProblemList from "@/components/doctor-workspace/ProblemList";
import ConsultationPanel from "@/components/doctor-workspace/ConsultationPanel";
import DiagnosisFormulation from "@/components/doctor-workspace/DiagnosisFormulation";
import PrescriptionPanel from "@/components/doctor-workspace/PrescriptionPanel";
import DiagnosticOrders from "@/components/doctor-workspace/DiagnosticOrders";
import ImagingTracings from "@/components/doctor-workspace/ImagingTracings";
import DispositionEducation from "@/components/doctor-workspace/DispositionEducation";

export default function DoctorWorkspacePage() {
  return (
    <div>
      <PatientHeader />
      <AlertsRow />
      <WorkspaceTabs />

      <div className="mt-5 grid grid-cols-1 gap-5 lg:grid-cols-[280px_1fr_280px]">
        <div className="space-y-5">
          <TriageVitals />
          <ProblemList />
        </div>

        <div className="space-y-5">
          <ConsultationPanel />
          <DiagnosisFormulation />
          <PrescriptionPanel />
        </div>

        <div className="space-y-5">
          <DiagnosticOrders />
          <ImagingTracings />
          <DispositionEducation />
        </div>
      </div>
    </div>
  );
}
