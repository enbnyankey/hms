import type { Metadata } from "next";
import "./globals.css";
import Sidebar from "@/components/Sidebar";
import Topbar from "@/components/Topbar";
import NoticeBanner from "@/components/NoticeBanner";

export const metadata: Metadata = {
  title: "AuraHealth HMS",
  description: "Enterprise Clinical Cloud — Hospital Management System",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className="font-sans antialiased">
        <div className="flex h-screen overflow-hidden">
          <Sidebar />
          <div className="flex flex-1 flex-col overflow-hidden">
            <Topbar />
            <NoticeBanner />
            <main className="flex-1 overflow-y-auto px-4 py-6 lg:px-6">{children}</main>
          </div>
        </div>
      </body>
    </html>
  );
}
