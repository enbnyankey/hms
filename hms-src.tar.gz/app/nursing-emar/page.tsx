import PlaceholderPage from "@/components/PlaceholderPage";
import { ClipboardList } from "lucide-react";

export default function Page() {
  return (
    <PlaceholderPage
      icon={ClipboardList}
      title="Nursing & eMAR"
      description="Medication administration records, nursing vitals charting, and shift handover notes."
    />
  );
}
