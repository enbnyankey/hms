import PlaceholderPage from "@/components/PlaceholderPage";
import { BarChart3 } from "lucide-react";

export default function Page() {
  return (
    <PlaceholderPage
      icon={BarChart3}
      title="Reports & Analytics"
      description="Operational, clinical, and financial reporting with exportable dashboards for hospital leadership."
    />
  );
}
